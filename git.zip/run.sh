import os
import subprocess

# Activate the virtual environment
activate_env = '/home/alimzade/virtualenv/story.alimzade.com/3.9/bin/activate_this.py'
exec(open(activate_env).read(), {'__file__': activate_env})

# Change to the project directory
os.chdir('/home/alimzade/story.alimzade.com')

# Run the uvicorn command
subprocess.call(['python', '-m', 'uvicorn', 'main:app', '--host', '0.0.0.0', '--port', '3001'])