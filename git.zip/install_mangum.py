import os
import subprocess

def install_mangum():
    # Install Mangum using pip
    try:
        subprocess.check_call(["pip", "install", "mangum"])
        print("Mangum installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error installing Mangum: {e}")

if __name__ == "__main__":
    install_mangum()
