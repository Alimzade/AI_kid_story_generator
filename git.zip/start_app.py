import os
import subprocess

# Path to your virtual environment's Python interpreter
venv_python = "/home/alimzade/virtualenv/story.alimzade.com/3.9/bin/python"

# Command to run Uvicorn with your app
command = [
    venv_python, "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "3001"
]

# Run the Uvicorn server
subprocess.run(command)