import subprocess
import sys

# Define the path to the Python executable inside your virtual environment
venv_python = "/home/alimzade/virtualenv/story.alimzade.com/3.9/bin/python3"

# Run the command to install psutil using subprocess
subprocess.check_call([venv_python, "-m", "pip", "install", "psutil", "source","uvicorn"])

print("psutil installed successfully")