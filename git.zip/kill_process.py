import os
import signal
import psutil

def find_and_kill_process(port):
    try:
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                connections = proc.connections(kind='inet')  # Retrieve connections for the process
                for conn in connections:
                    if conn.status == psutil.CONN_LISTEN and conn.laddr.port == port:
                        print(f"Process {proc.info['name']} with PID {proc.info['pid']} is using port {port}.")
                        os.kill(proc.info['pid'], signal.SIGKILL)  # Kill the process
                        print(f"Process with PID {proc.info['pid']} has been killed.")
                        return
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                # Handle cases where we don't have permission or the process has already exited
                continue
        print(f"No process found on port {port}.")
    except Exception as e:
        print(f"Error occurred: {e}")

# Example usage
find_and_kill_process(3001)